filename = ""
model.load_weights(filename)
model.compile(loss='categorical_crossentropy', optimizer='adam')


